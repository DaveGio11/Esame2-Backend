--1. CONTEGGIO DEL NUMERO DEI VERBALI EFFETTUATI
-- SELECT COUNT (*) FROM Verbal AS elencoVerbali 

--2. CONTEGGIO DEI VERBALI TRASCRITTI RAGGRUPPATI PER idAnagrafica
-- SELECT COUNT (*) FROM Verbal AS verbaliIdAnag GROUP BY idAnagrafica

--3. CONTEGGIO VERBALI RAGGRUPPATI PER idViolazione
-- SELECT COUNT (*) FROM Verbal AS verbaliIdViol GROUP BY idViolazione

--4. Calcolo dei pt sottratti ad ogni soggetto
-- SELECT idAnagrafica, SUM(DecurtamentoPunti) AS totPtDecurtati FROM Verbal GROUP BY idAnagrafica

--5. Cognome, Nome, Data violazione, Indirizzo violazione, importo e punti decurtati per tutti gli anagrafici residenti a Palermo
-- SELECT A.Nome, 
-- A.Cognome, 
-- A.Nome, 
-- V.Dataviolazione AS DataViolazione,
-- V.IndirizzoViolazione AS IndirizzoViolazione,  
-- V.Importo, 
-- V.DecurtamentoPunti
-- FROM 
-- Verbal V
-- JOIN 
-- Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
-- WHERE 
-- A.Citta = 'Palermo';

-- Il metodo JOIN combina le righe di due o pi� tabelle

-- 6. Cognome, Nome, Indirizzo, Data violazione, importo e punti decurtati per le violazioni fatte tra il febbraio 2009 e luglio 2009, 
--SELECT 
--A.Nome, 
--A.Cognome, 
--A.indirizzo AS IndirizzoPersona, 
--V.DataViolazione AS DataViolazione, 
--V.Importo, 
--V.DecurtamentoPunti
--FROM 
--Verbal V
--JOIN 
--Anagrafica A ON V.IdAnagrafica = A.IdAnagrafica
--WHERE 
--V.DataViolazione >= '2023-02-01' AND V.DataViolazione <= '2023-08-31';

-- 7. Totale degli importi per ogni anagrafico, 
--SELECT
--A.Nome,
--A.Cognome,
--A.indirizzo As IndirizzoPersona,
--SUM(V.Importo) AS TotalePecunia
--FROM 
--Verbal V
--JOIN
--Anagrafica A ON V.idAnagrafica = A.idAnagrafica
--GROUP BY
--V.idAnagrafica, A.Nome, A.Cognome, A.indirizzo;

-- 8. Visualizzazione di tutti gli anagrafici residenti a Palermo, 
-- SELECT * FROM Anagrafica WHERE Citta = 'Palermo'

-- 10. Conteggio delle violazioni per IndirizzoViolazione raggruppate per IdentificativoAgente dell�agente di Polizia, 
-- SELECT IdentificativoAgente, IndirizzoViolazione, COUNT(*) AS VerbaliPerIndirizzoViolazione
--FROM Verbal  
--GROUP BY IdentificativoAgente, IndirizzoViolazione;

-- 11. Cognome, Nome, Indirizzo, Data violazione, Importo e punti decurtati per tutte le violazioni che superino il decurtamento di 5 punti, 

--SELECT 
-- A.Nome, 
--A.Cognome, 
--A.indirizzo AS IndirizzoPersona, 
--V.DataViolazione AS DataViolazione, 
--V.Importo, 
--V.DecurtamentoPunti
--FROM 
--Verbal V
--JOIN 
--Anagrafica A ON V.IdAnagrafica = A.IdAnagrafica
--WHERE 
--V.DecurtamentoPunti > 5

-- 12. Cognome, Nome, Indirizzo, Data violazione, Importo e punti decurtati per tutte le violazioni che superino l�importo di 400 euro. 
--SELECT 
--A.Nome, 
--A.Cognome, 
--A.indirizzo AS IndirizzoPersona, 
--V.DataViolazione AS DataViolazione, 
--V.Importo, 
--V.DecurtamentoPunti
--FROM 
--Verbal V
--JOIN 
--Anagrafica A ON V.IdAnagrafica = A.IdAnagrafica
--WHERE 
--V.Importo > 400


