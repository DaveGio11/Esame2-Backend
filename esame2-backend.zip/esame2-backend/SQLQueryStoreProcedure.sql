-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

-- 9. Query parametrica che visualizzi Data violazione, Importo e decurta mento punti relativi ad una certa data
--DECLARE @dataViolazione DATE = '2023-08-15'; -- Sostituisci con la data desiderata

--SELECT
    --DataViolazione AS DataViolazione,
    --Importo,
    --DecurtamentoPunti
--FROM
    --Verbal
--WHERE
  --  DataViolazione = @dataViolazione;



--1) Una SP parametrica che, ricevendo in input un anno, visualizzi l�elenco delle contravvenzioni effettuate in un quel determinato anno
-- DECLARE @AnnoViolazione DATE = '2023';

--SELECT
    --DataVerbale AS DataViolazione,
    --Importo,
    --DecurtamentoPunti,
    --COUNT(*) AS ContrAnnue
--FROM 
    --Verbal
--WHERE
    --YEAR(DataViolazione) = YEAR(@AnnoViolazione)
--GROUP BY 
    --IdentificativoAgente, DataVerbale, Importo, DecurtamentoPunti;

-- 2) Una SP parametrica che, ricevendo in input una data, visualizzi il totale dei punti decurtati in quella determinata data
--DECLARE @puntiDecurtati DATE = '2023-08-14';

--SELECT 
   -- SUM(DecurtamentoPunti) AS TotalePuntiDecurtati
--FROM 
    --Verbal
--WHERE
    --DataVerbale = @puntiDecurtati;


-- 3) Una SP che consenta di eliminare un determinato verbale identificandolo con il proprio identificativo. 
DECLARE @idDelete INT = 12;

DELETE FROM Verbal
WHERE idVerbale = @idDelete;

