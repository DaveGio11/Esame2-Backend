INSERT INTO TipoViolazioni (Descrizione, idVerbale ) 
VALUES
( 'Eccesso di velocit�', 2),
( 'Attraversamento semaforo rosso',3),
('Sosta vietata',4 ),
( 'Guida senza cintura di sicurezza',5),
( 'Utilizzo del telefono cellulare mentre si guida',6),
('Manovre pericolose',7 ),
( 'Guida in stato di ebbrezza',8),
( 'Infrazione del codice della strada',9),
( 'Guida senza patente',10),
('Guida senza assicurazione',11 ),
( 'Guida sotto effetto di sostanze stupefacenti',12),
('Veicolo non revisionato',13),
('Mancato rispetto della segnaletica stradale',14 ),
( 'Guida in contromano',15),
( 'Distanza di sicurezza non mantenuta',16);